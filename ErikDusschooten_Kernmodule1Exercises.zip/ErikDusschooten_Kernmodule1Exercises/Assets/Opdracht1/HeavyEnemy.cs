﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeavyEnemy : ActorBase
{
    public override void Move()
    {
    }

    public override void Attack()
    {
    }

    public override void TakeDamage()
    {
    }
}
