﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : ActorBase
{
 
    public override void Move()
    {
    }

    public override void Attack()
    {
    }

    public override void TakeDamage()
    {
    }
}
